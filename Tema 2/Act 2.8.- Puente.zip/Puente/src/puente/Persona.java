package puente;

import java.util.Random;
public class Persona extends Thread{
    
    private final String nombre;
    private final Puente puente;
    private final int peso;

    public Persona(String nombre, Puente puente) {
        this.nombre = nombre;
        this.puente = puente;
        this.peso = generarPeso();
    }

    public String getNombre() {
        return nombre;
    }

    public int getPeso() {
        return peso;
    }

    private int generarPeso(){
        Random r = new Random();
        return r.nextInt(40,121);
    }

    @Override
    public void run() {
        
        try {
           puente.cruzarPuente(this);
        } catch (InterruptedException ex) {
            System.out.printf("ERROR: %s\n", ex.getMessage());
        }
        
    }

}
