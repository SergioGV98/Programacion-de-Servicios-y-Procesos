package puente;

public class Main {

    public static void main(String[] args) {
        Puente puente = new Puente();

        Persona[] personas = new Persona[15];
        for (byte i = 0; i < 15; i++) {
            personas[i] = new Persona("Persona " + i, puente);
        }

        for (Persona persona : personas) {
            persona.start();
        }
        
    }

}
