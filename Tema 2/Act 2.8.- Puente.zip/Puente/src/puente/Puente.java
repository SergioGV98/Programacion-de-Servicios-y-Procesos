package puente;

import java.util.Random;

public class Puente {

    private int cantidadPersonas = 0;
    private int cantidadPesoActual = 0;

    public Puente() {
    }

    public synchronized void cruzarPuente(Persona p) throws InterruptedException {
        while (cantidadPersonas >= 3 && cantidadPesoActual + p.getPeso() > 200) {
            System.out.printf("[%s] con peso %skg. Espera a cruzar el puente.\n", p.getNombre(), p.getPeso());
            p.wait();
        }

        cantidadPersonas++;
        cantidadPesoActual += p.getPeso();

        System.out.printf("[%s] cruza el puente\n", p.getNombre());
        System.out.printf("Personas en el puente: %d - Peso en el puente: %d\n", cantidadPersonas, cantidadPesoActual);

        int tiempo = new Random().nextInt(1000, 50001);
        int tiempoMostrar = tiempo / 1000;
        System.out.printf("%s%s me quedan %d segundos para terminar de cruzar.\n", "\u001B[31m", p.getNombre(), tiempoMostrar);
        Thread.sleep(tiempo);

        cantidadPersonas--;
        cantidadPesoActual -= p.getPeso();
        System.out.printf("[%s] con peso %skg. Termino de cruzar el puente.\n", p.getNombre(), p.getPeso());

        notifyAll(); 
    }

}
