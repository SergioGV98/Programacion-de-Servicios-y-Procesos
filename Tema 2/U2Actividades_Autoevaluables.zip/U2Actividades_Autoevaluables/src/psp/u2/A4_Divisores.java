
package psp.u2;

public class A4_Divisores {

    public static void main(String[] args) {
        
        A4_Divisores1 a1 = new A4_Divisores1();
        a1.start();
        
        A4_Divisores2 a2 = new A4_Divisores2();
        a2.start();
        
    }
    
}
