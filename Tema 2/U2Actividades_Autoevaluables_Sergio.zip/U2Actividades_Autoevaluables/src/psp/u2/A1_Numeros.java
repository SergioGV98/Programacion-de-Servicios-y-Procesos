package psp.u2;


public class A1_Numeros {

    public static void main(String[] args) {
        A1_Numeros1 nNumeros1 = new A1_Numeros1();
        A1_Numeros2 nNumeros2 = new A1_Numeros2();
        nNumeros1.start();
        nNumeros2.start();
    }
    
}
