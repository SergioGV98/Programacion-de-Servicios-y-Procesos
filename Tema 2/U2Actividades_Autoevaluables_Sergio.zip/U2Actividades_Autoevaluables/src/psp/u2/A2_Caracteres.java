
package psp.u2;

public class A2_Caracteres {
    
    public static void main(String[] args) {
        A2_Caracteres1 a1 = new A2_Caracteres1();
        a1.start();
        
        A2_Caracteres2 a2 = new A2_Caracteres2();
        a2.start();
    }

}
