package psp.u2;

public class A8_Series {

    public static void main(String[] args) {
        A8_Series1 hilo1 = new A8_Series1();
        A8_Series1 hilo2 = new A8_Series1();
        A8_Series1 hilo3 = new A8_Series1();

        hilo1.start();
        hilo2.start();
        hilo3.start();
    }

}
