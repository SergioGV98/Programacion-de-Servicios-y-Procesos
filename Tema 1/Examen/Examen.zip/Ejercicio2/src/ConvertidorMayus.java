public class ConvertidorMayus {
    
    public static void main(String[] args) {
        String frase = args[0];
        
        System.out.println(frase.toUpperCase());
    }
    
}
